son(t(R,nil,nil)).
son(t(R,G,D)):-G\=nil,D\=nil,!,write(R),son(G),son(D).
son(t(R,G,nil)):-G\=nil,!,son(G).
son(t(R,nil,D)):-D\=nil,!,son(D).
