%Q2

repas(P)-->entree(P1),plat(P2),{P is P1+P2}.
repas(P)-->plat(P2),dessert(P3),{P is P2+P3}.
repas(P)-->entree(_),plat(_),dessert(_),{P is 15}.


entree(2)-->[soupe].
entree(3)-->[salade].

plat(10)-->legume,proteine.
legume-->[carotte];[brocoli];[asperge].
proteine-->[saumon];[boeuf];[poulet];[tofu].


dessert(4)-->[gateau].
dessert(5)-->[tarte].