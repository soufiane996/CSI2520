:-dynamic student/3,evaluation/4,mark/4.

%Q1 a):(utiliser la requete listing(student) pour voir tous les etudiants.

% name, studentId, course list
student(name(blake, [ann]), 33333, ['CSI2120'] ).

% course, type, name as list of text, maximum marks
evaluation('CSI2120', assignment(1), ['Prolog', database ], 5).
evaluation('CSI2120', midterm(1), ['Prolog', database ], 26).%jai ajoute cette ligne pour pouvoir mettre les notes du midterm.

% course, studentId, evaluation, mark
mark('CSI2120', 33333, assignment(1), 3.5 ).

addStudent:-
write('Student last name:'),nl,read(X),
write('Student first name:'),nl,read(Y),
write('Student Id:'),nl,read(Z),
\+student(name(X,Y), Z,_),
assert(student(name(X, Y),Z,[])).

%Q1 b)

add(X,Y):-student(name(A,B),Y,L),\+member(X,L),
retract(student(name(A,B),Y,L)),
assert(student(name(A,B),Y,[X|L])).

%Q1 c)
addAllMarks(X,Y):-student(name(Last,First),D,L),member(X,L),
evaluation(X,Y,_,Bareme),
validInput(First,Last,Bareme,M),
assert(mark(X,D,Y,M)),
fail.

validMark(M,Bareme):-M>=0,M=<Bareme.
validInput(First,Last,Bareme,M):-write("name("),write(Last),
write(','),write(First),
write(") Mark (out of "),write(Bareme),write('):'),read(M),nl,
validMark(M,Bareme),!.

validInput(First,Last,Bareme,M):-validInput(First,Last,Bareme,M).

%Q1 d)
listAllMarks(X,Y,L):-setof((ID,Mark),mark(X,ID,Y,Mark),L).

%Q1 e)

averageMark(X,Y,A):-findall(M,mark(X,ID,Y,M),L),somme(L,S),
length(L,T), A is S/T.

somme([],0).
somme([X|L],T):-somme(L,TT), T is X+TT.