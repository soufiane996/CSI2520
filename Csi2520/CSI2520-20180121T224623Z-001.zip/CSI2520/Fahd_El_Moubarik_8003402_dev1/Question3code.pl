couleur(lobelia,bleu).

couleur(impatientes,rouge).
couleur(impatientes,blanc).
couleur(impatientes,rose).

couleur(pervenche,bleu).

couleur(anemone,rose).
couleur(anemone,blanc).

couleur(marigold,jaune).
couleur(marigold,orange).

couleur(ladySusan,jaune).

couleur(coeurSaignant,rose).
couleur(coeurSaignant,blanc).

couleur(chrysantheme,rouge).
couleur(chrysantheme,jaune).
couleur(chrysantheme,bleu).
couleur(chrysantheme,blanc).

couleur(lupin,jaune).

couleur(bruyere,pourpre).

couleur(iris,bleu).
couleur(iris,orange).
couleur(iris,rose).
couleur(iris,rouge).
couleur(iris,blanc).

couleur(phlox,pourpre).
couleur(phlox,rouge).
couleur(phlox,rose).

taille_min(lobelia,6).
taille_max(lobelia,12).

taille_min(impatientes,12).
taille_max(impatientes,36).

taille_min(pervenche,0).
taille_max(pervenche,6).

taille_min(anemone,12).
taille_max(anemone,36).

taille_min(marigold,3).
taille_max(marigold,12).

taille_min(ladySusan,12).
taille_max(ladySusan,24).

taille_min(coeurSaignant,6).
taille_max(coeurSaignant,12).

taille_min(chrysantheme,12).
taille_max(chrysantheme,36).

taille_min(lupin,12).
taille_max(lupin,96).

taille_min(bruyere,36).
taille_max(bruyere,96).

taille_min(iris,6).
taille_max(iris,36).

taille_min(phlox,12).
taille_max(phlox,36).

zone_min(lobelia,2).
zone_max(lobelia,11).

zone_min(impatientes,10).
zone_max(impatientes,11).

zone_min(pervenche,4).
zone_max(pervenche,9).

zone_min(anemone,4).
zone_max(anemone,8).

zone_min(marigold,7).
zone_max(marigold,10).

zone_min(ladySusan,3).
zone_max(ladySusan,11).

zone_min(coeurSaignant,3).
zone_max(coeurSaignant,9).

zone_min(chrysantheme,5).
zone_max(chrysantheme,9).

zone_min(lupin,4).
zone_max(lupin,8).

zone_min(bruyere,6).
zone_max(bruyere,10).

zone_min(iris,3).
zone_max(iris,9).

zone_min(phlox,2).
zone_max(phlox,11).

periode(lobelia,annuelle).

periode(impatientes,annuelle).

periode(pervenche,vivace).

periode(anemone,vivace).

periode(marigold,annuelle).

periode(ladySusan,annuelle).

periode(coeurSaignant,vivace).

periode(chrysantheme,vivace).

periode(lupin,vivace).

periode(bruyere,vivace).

periode(iris,vivace).

periode(phlox,annuelle).

robuste(X):-zone_min(X,Y), zone_max(X,Z), taille_max(X,T), Y<7, Z>5, T>47.

trio(C1,P1,C2,P2,C3,P3):-couleur(P1,C1), couleur(P2,C2), couleur(P3,C3), P1\=P2, P1\=P3, P2\=P3,!.




  