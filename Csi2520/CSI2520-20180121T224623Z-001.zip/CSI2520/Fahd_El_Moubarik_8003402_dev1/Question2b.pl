sosd(0,0).
sosd(X,Y):-X>0, X1 is X//10, Y1 is mod(X,10),sosd(X1,Y2), Y is Y1*Y1+Y2.
happyStop(X):-(X=:=1),!,writeln(X).
happyStop(X):-(X=:=0;X=:=4;X=:=16;X=:=20;X=:=37;X=:=42;X=:=58;X=:=89;X=:=145),!,writeln(X),false.
happyStop(X):-sosd(X,Y),happyStop(Y).