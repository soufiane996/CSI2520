sosd(0,0).
sosd(X,Y):-X>0, X1 is X//10, Y1 is mod(X,10),sosd(X1,Y2), Y is Y1*Y1+Y2.