harmonic(0,0).
harmonic(N,X):-N>0, N1 is N-1, harmonic(N1,Y), X is Y+1/N.