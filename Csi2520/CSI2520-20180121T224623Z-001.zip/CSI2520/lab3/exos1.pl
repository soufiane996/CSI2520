decompte(0):-writeln(0).
decompte(N):- N>=0, writeln(N),X is N-1, decompte(X).