divisible(D,D,X):-X is D.
divisible(D,U,X):-D<U,U mod D=\=0, R is U mod D, U1 is U-R, divisible(D,U1,X).
divisible(D,U,X):-D<U, U mod D=:=0, U1 is U-D, divisible(D,U1,X).
divisible(D,U,X):-D<U, U mod D=:=0, X is U.  

divisibleAll(D,U,L):-setof(X,divisible(D,U,X),L).