colors([blue,yellow,green,red]).
letters([w,x,y,z]).

generate(C,L,H):-H is C.
