blast([X,Y],X).
blast(L,A):-blast(.
