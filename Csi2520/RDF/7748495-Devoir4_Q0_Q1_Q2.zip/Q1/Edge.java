public class Edge {


        public Node parent = null;
        public Node enfant = null;
        public double distance;
        //Constructor for the edge class
        public Edge(Node parent, Node enfant, double distance) {
            this.parent = parent;
            this.enfant = enfant;
            this.distance = distance;
        }



}
